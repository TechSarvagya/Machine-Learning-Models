import React from "react";
import Chatinterface from "./Components/Chatinterface";


const Chat =() =>{
    return <Chatinterface />;
};

export default Chat;