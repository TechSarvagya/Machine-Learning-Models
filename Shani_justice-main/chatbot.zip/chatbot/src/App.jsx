import React from 'react';
import Home from './Home';
import Header from './Components/Header';
//import Footer from './Components/Footer';
import Login from './Components/Login';
import Signup from './Components/Signup';
import Chat from './Chat';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import {ThemeProvider} from "styled-components";
import { GlobalStyle } from './GlobalStyle';

function App() {

  const theme = {
    colors:{
      heading: "#262323",
      text: "#262323",
      white: "#FFFFFF",
      black: "#262626",
      helper: "#4F79C7",
      bg: "rgb(249 249 255)",
      footer_bg: "#0a1435",
      btn: "#94BDF2",
      border: "#0D65D9",
      hr: "#ffffff",
      gradient: "linear-gradient(0deg, rgba(132,144,255,1) 0%, rgba(75,116,192,0.9080882352941176) 66%)",
    },
    media:{mobile: "768px", tab: "998px"},
  };

  return (
    <ThemeProvider theme={theme}>
    <GlobalStyle />
    <BrowserRouter>
     <Header />
     <Routes>
      <Route path="/" element={<Home />} /> 
      <Route path="/Chat" element={<Chat />} />
      <Route path="/Login" element={<Login />} />
      <Route path="/Signup" element={<Signup />} />
    
     </Routes>
    </BrowserRouter>
    </ThemeProvider>
  );
}


export default App
