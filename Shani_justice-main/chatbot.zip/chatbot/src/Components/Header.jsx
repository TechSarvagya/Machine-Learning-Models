import React from 'react';
import styled from 'styled-components';
import { NavLink} from 'react-router-dom';
import Navbar from './Navbar';

const Header = () =>{
    return(
        <>
        <Mainheader>
            <NavLink to="/">
                <h2>Shani</h2>
            </NavLink>
            <Navbar />
        </Mainheader>
        </>
        

    );
};

const Mainheader = styled.header`
padding: 0 4.8rem;
height: 7rem;
background-color: ${({theme}) => theme.colors.bg};
display: flex;
justify-content: space-between;
align-items: center;

li{
    list-style: none;


    .navbar-link{
        &:link,
        &:visited {
            display: inline-block;
            text-decoration: none;
            font-size: 1.4rem;
            font-weight: 500;
            text-transform: uppercase;
            color: ${({theme}) => theme.colors.black};
            transition: color 0.3s linear;

        }

        &:hover,
        &:active {
            color: ${({theme}) => theme.colors.helper};
        }
    }
  }
`;

export default Header