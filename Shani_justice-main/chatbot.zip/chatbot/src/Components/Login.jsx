import React from 'react';
import styled from 'styled-components';

const Login = () => {
    return (
        <Wrapper>
            <h2>Login</h2>
            <form>
                <div>
                    <label>Email:</label>
                    <input type="email" placeholder="Enter your email" required />
                </div>
                <div>
                    <label>Password:</label>
                    <input type="password" placeholder="Enter your password" required />
                </div>
                <button type="submit">Login</button>
            </form>
        </Wrapper>
    );
};

const Wrapper = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #f4f4f9;
    form {
        display: flex;
        flex-direction: column;
        width: 300px;
        div {
            margin-bottom: 15px;
        }
        label {
            margin-bottom: 5px;
        }
        input {
            padding: 10px;
            font-size: 1rem;
            width: 100%;
            box-sizing: border-box;
        }
        button {
            padding: 10px;
            font-size: 1rem;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            &:hover {
                background-color: #0056b3;
            }
        }
    }
`;

export default Login
