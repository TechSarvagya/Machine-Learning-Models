import React from "react";
import styled from "styled-components";
import { NavLink } from "react-router-dom";
import Button from "../styles/Button";


const HeroSection = () =>{
    return (
    <Wrapper>
        <div className="container grid">
            <div className="section-hero-data">
                <p> Your Legal Ally </p>
                <h2 className="hero-heading"> Simplifying India's Laws and Sections for You.</h2>
                {/* <p className="hero-para">{props.heropara}</p> */}
                <Button className="hero-button">
                    <NavLink to="/Chat">Chat Now</NavLink>
                </Button> 
            </div>
            {/* <div className="section-hero-image">
                <picture>
                    <img src={props.image} alt="hero image"/>
                </picture>
            </div> */}
        </div>

    </Wrapper>
  );
};

const Wrapper = styled.section`
padding: 10rem 0;
display: flex;
ustify-content: center;
align-items: center;
height: 100vh; /* Full viewport height */
background-color: #f4f4f9; /* Matching the chat page background color */

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    width: 100%;
}


.section-hero-data{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    

    
 }

.hero-heading{
    text-align: center;
    margin-top: 10px;
}

.hero-button{
    margin-top: 20px;
    max-width: 15rem;
    padding: 0.75rem 1.5rem;
    border-radius: 5px;
    transition: background-color 0.3s ease;
    background-color: ${({theme}) => theme.colors.black};
    
}


`;

export default HeroSection