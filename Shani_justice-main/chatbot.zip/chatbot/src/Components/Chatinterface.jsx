import React from "react";
import styled from "styled-components";

const Chatinterface = () => {
    return (
        <Wrapper>
            {/* <Sidebar className='sidebar1' /> */}
            <Content>
                <h1 className='h1'>How can I help you today?</h1>
                <div className='div1'>
                    <Comp className="comp-container">{'Your Rights?'}</Comp>
                    <Comp className="comp-container">{'Search About Judicial Law'}</Comp>
                    <Comp className="comp-container">{'Give me ideas'}</Comp>
                    <Comp className="comp-container">{'View Constitution'}</Comp>
                </div>
                <div className='div2'>
                    <input className='input1' placeholder='Write Your Query'></input>
                </div>
                <h5 className='h5-1'>We give general advice, please consider a lawyer for detailed information.</h5>
            </Content>
        </Wrapper>
    );
};

// function Sidebar({ className }) {
//     return (
//         <div className="sidebar">
//             <div className={className}>Login</div>
//             <div className={className}>Signup</div>
//         </div>
//     )
// }

function Comp({ children, className }) {
    return (
        <div className={className}>
            {children}
        </div>
    )
}

const Wrapper = styled.section`
    display: flex;
    height: 100vh;
    background-color: #f4f4f9;
    color: #333;
    font-family: Arial, Helvetica, sans-serif;

    // .sidebar {
    //     display: flex;
    //     flex-direction: column;
    //     align-items: center;
    //     justify-content: center;
    //     background-color: #2c3e50;
    //     padding: 2rem;
    //     width: 15%;
    //     min-width: 200px;
    // }

    // .sidebar1 {
    //     margin: 1rem 0;
    //     padding: 1rem;
    //     text-align: center;
    //     font-size: 1.2rem;
    //     color: white;
    //     background-color: #34495e;
    //     border: 2px solid #fff;
    //     border-radius: 20px;
    //     cursor: pointer;
    //     width: 80%;
    //     transition: background-color 0.3s ease;

    //     &:hover {
    //         background-color: #1abc9c;
    //     }
    // }
`;

const Content = styled.div`
    flex: 1;
    padding: 2rem;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    .h1 {
        margin-bottom: 2rem;
        font-size: 3rem;
        text-align: center;
    }

    .div1 {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin-bottom: 2rem;
    }

    .comp-container {
        margin: 10px;
        padding: 1.5rem 2.5rem;
        font-size: 1.5rem;
        border: 2px solid #ccc;
        border-radius: 10px;
        cursor: pointer;
        transition: background-color 0.3s ease;

        &:hover {
            background-color: #dcdcdc;
        }
    }

    .input1 {
        width: 100%;
        max-width: 600px;
        padding: 1rem;
        font-size: 2rem;
        border: 2px solid #ccc;
        border-radius: 10px;
        margin-bottom: 1rem;
    }

    .h5-1 {
        margin-top:10px;
        font-size: 2rem;
        color: #555;
        text-align: center;
    }
`;

export default Chatinterface;

