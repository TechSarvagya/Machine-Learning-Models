import React from "react";
import { NavLink } from "react-router-dom";
import styled from "styled-components";
//import { Button } from "../styles/Button";


const Navbar=()=>{
    return <Nav>
        <div className="menuIcon">
            <ul className="navbar-list">
                <li>
                <NavLink className ="navbar-link " to="/">Home</NavLink>
                </li>
            </ul>
        </div>
    </Nav>
    
};

const Nav= styled.nav`
`;

export default Navbar