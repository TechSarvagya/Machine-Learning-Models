import React from 'react';
import styled from 'styled-components';

const Signup = () => {
    return (
        <Wrapper>
            <h2>Signup</h2>
            <form>
                <div>
                    <label>Email:</label>
                    <input type="email" placeholder="Enter your email" required />
                </div>
                <div>
                    <label>Password:</label>
                    <input type="password" placeholder="Enter your password" required />
                </div>
                <div>
                    <label>Confirm Password:</label>
                    <input type="password" placeholder="Confirm your password" required />
                </div>
                <button type="submit">Signup</button>
            </form>
        </Wrapper>
    );
};

const Wrapper = styled.div`
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background-color: #f4f4f9;
    form {
        display: flex;
        flex-direction: column;
        width: 300px;
        div {
            margin-bottom: 15px;
        }
        label {
            margin-bottom: 5px;
        }
        input {
            padding: 10px;
            font-size: 1rem;
            width: 100%;
            box-sizing: border-box;
        }
        button {
            padding: 10px;
            font-size: 1rem;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            &:hover {
                background-color: #218838;
            }
        }
    }
`;

export default Signup
