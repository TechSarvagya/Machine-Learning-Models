import React from 'react';
import HeroSection from './Components/HeroSection';

const Home =()=>{
    return <HeroSection />
};

export default Home